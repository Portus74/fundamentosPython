#3iv. Exemplo de IndexError: 
try: 
    lista = [1, 2, 3]   
    print(lista[5]) 
except IndexError: 
    print("Erro: Índice fora do alcance da lista.")
