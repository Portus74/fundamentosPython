#3x. Exemplo de RuntimeError: 
try: 
    raise RuntimeError("Erro inesperado!") 
except RuntimeError: 
    print("Erro: Ocorreu um erro inesperado durante a execução.")